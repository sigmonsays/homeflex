<?
	$theme_link_class = "";
	$theme_link_prefix = "";
	$theme_link_suffix = "<BR>";
	$theme_link_last_tag = "";

        $theme_link2_class = "";
        $theme_link2_prefix = '';
        $theme_link2_suffix = '';
        $theme_link2_last_tag = "";

?>
