<?
	$theme_link_class = "link";
	$theme_link_prefix = "<td bgcolor=#ffdf00 align=center>";
	$theme_link_suffix = '</td>';
	$theme_link_last_tag = "";


	$theme_link2_class = "link";
	$theme_link2_prefix = '<br> &nbsp; ';
	$theme_link2_suffix = ' &nbsp; <br>';
	$theme_link2_last_tag = "";
?>
