<?

	$theme_link_class = "";
	$theme_link_prefix = '<tr><td class="basic" bgcolor="#9FAC9F">';
	$theme_link_suffix = '/</td></tr>';
	$theme_link_last_tag = "";

	$theme_link2_class = "";
	$theme_link2_prefix = '<tr><td class="basic" bgcolor="#9FAC9F">';
	$theme_link2_suffix = '/</td></tr>';
	$theme_link2_last_tag = "";


?>
