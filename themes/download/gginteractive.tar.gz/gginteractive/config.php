<?
	$theme_link_class = "";
	$theme_link_prefix = "<tr><td><div align=\"left\">&raquo; ";
	$theme_link_suffix = "</div></td></tr>\n";
	$theme_link_last_tag = "";

	$theme_link2_class = "";
	$theme_link2_prefix = "<tr><td><div align=\"left\">- ";
	$theme_link2_suffix = "</div></td></tr>\n";
	$theme_link2_last_tag = "";


?>
