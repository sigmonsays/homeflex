<?
	$theme_link_class = "toolbar";

	$theme_link_prefix = "<tr style=\"background-image: url(/homeInc/themes/bluemetal/_files/spacer.gif);\" 
onmouseover=\"this.style.backgroundImage='URL(/homeInc/themes/bluemetal/_files/button_on.gif)'; return true\"
onmouseout=\"this.style.backgroundImage='URL(/homeInc/themes/bluemetal/_files/spacer.gif)';\"><td>";
	$theme_link_suffix = "</td></tr>";
	$theme_link_last_tag = "";

	$theme_link2_class = "toolbar";
	$theme_link2_prefix = "<tr style=\"background-image: url(/homeInc/themes/bluemetal/_files/spacer.gif);\" 
onmouseover=\"this.style.backgroundImage='URL(/homeInc/themes/bluemetal/_files/button_on.gif)'; return true\"
onmouseout=\"this.style.backgroundImage='URL(/homeInc/themes/bluemetal/_files/spacer.gif)';\"><td>";
        $theme_link2_suffix = "</td></tr>";
        $theme_link2_last_tag = "";

?>
