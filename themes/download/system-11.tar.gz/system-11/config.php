<?
	$theme_link_class = "leftMenu";
	$theme_link_prefix = "<tr><td height='18'>";
	$theme_link_suffix = "</td></tr>\n";
	$theme_link_last_tag = "";

	$theme_link2_class = "leftMenu";
	$theme_link2_prefix = "<tr><td height='18'>";
	$theme_link2_suffix = "</td></tr>\n";
	$theme_link2_last_tag = "";
?>
