<?
	$theme_link_class = "NArialSG";
	$theme_link_prefix = "&raquo; &nbsp; ";
	$theme_link_suffix = "<BR>";
	$theme_link_last_tag = "";

	$theme_link2_class = "";
	$theme_link2_prefix = "&nbsp; ";
	$theme_link2_suffix = "<BR>";
	$theme_link2_last_tag = "";
?>
