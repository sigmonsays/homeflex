<?
	$theme_link2_class = "navBar";
	$theme_link2_prefix = "&nbsp;|&nbsp;";
	$theme_link2_suffix = "\n";
	$theme_link2_last_tag = "";

        $theme_link_class = "";
        $theme_link_prefix = ' <b>&middot; ';
        $theme_link_suffix = "</b><br>\n";
        $theme_link_last_tag = "";

?>
