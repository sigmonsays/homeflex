<?
	$theme_link_class = "";
	$theme_link_prefix = '<img src="/homeInc/themes/reallyslick.com/_files/image-dot.png" width="5" height="5" align="absmiddle"> &nbsp; ';
	$theme_link_suffix = "<BR>";
	$theme_link_last_tag = "";


	$theme_link2_class = "";
	$theme_link2_prefix = '<img src="/homeInc/themes/reallyslick.com/_files/image-dot.png" width="5" height="5" align="absmiddle"> &nbsp; ';
	$theme_link2_suffix = "<BR>";
	$theme_link2_last_tag = "";


?>
