<?
	$theme_link_class = "leftmenu";
	$theme_link_prefix = "";
	$theme_link_suffix = "";
	$theme_link_last_tag = "STYLE=\"border-bottom: 0 solid black;\"";

        $theme_link2_class = "leftmenu";
        $theme_link2_prefix = '';
        $theme_link2_suffix = '';
        $theme_link2_last_tag = "STYLE=\"border-bottom: 0 solid black;\"";

?>
