<?
	$theme_link_class = "";
	$theme_link_prefix = "<li>";
	$theme_link_suffix = "</li>\n";
	$theme_link_last_tag = "";

	$theme_link2_class = "";
	$theme_link2_prefix = "<li>";
	$theme_link2_suffix = "</li>\n";
	$theme_link2_last_tag = "";
?>
