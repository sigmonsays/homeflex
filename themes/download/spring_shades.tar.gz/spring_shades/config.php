<?
	$theme_link_class = "";
	$theme_link_prefix = "<div>";
	$theme_link_suffix = "</div>\n";
	$theme_link_last_tag = "";

        $theme_link2_class = "";
        $theme_link2_prefix = '';
        $theme_link2_suffix = '';
        $theme_link2_last_tag = "";

?>
