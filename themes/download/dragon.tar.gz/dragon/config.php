<?
	$theme_link_class = "linkw";
	$theme_link_prefix = "";
	$theme_link_suffix = " &nbsp; :: <BR>";
	$theme_link_last_tag = "";

        $theme_link2_class = "linkw";
        $theme_link2_prefix = '';
        $theme_link2_suffix = ' &nbsp; :: <BR>';
        $theme_link2_last_tag = "";

?>
