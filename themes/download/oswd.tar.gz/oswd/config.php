<?
/*
<img src="%_files%/icon_affiliates.gif" width="10" height="10" border="0" alt="">
                                                <a class="secnav" href="http://oswd.org/premium.php">Premium Designs</a><br>
*/
	$theme_link_class = "secnav";
	$theme_link_prefix = '<img src="/homeInc/themes/oswd/_files/icon_affiliates.gif" width="10" height="10" border="0" alt="">';
	$theme_link_suffix = "<BR><BR>";
	$theme_link_last_tag = "";


	$theme_link2_class = "secnav";
	$theme_link2_prefix = '<img src="/homeInc/themes/oswd/_files/icon_affiliates.gif" width="10" height="10" border="0" alt="">';
	$theme_link2_suffix = "<BR><BR>";
	$theme_link2_last_tag = "";


?>
