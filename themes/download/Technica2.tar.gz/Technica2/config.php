<?
	$theme_link_class = "nav-link";
	$theme_link_prefix = "";
	$theme_link_suffix = "\n";
	$theme_link_last_tag = "";

        $theme_link2_class = "nav-link";
        $theme_link2_prefix = '';
        $theme_link2_suffix = "\n";
        $theme_link2_last_tag = "";

?>
