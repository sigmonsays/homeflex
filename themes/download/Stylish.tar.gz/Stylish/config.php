<?
	$theme_link_class = "link";
	$theme_link_prefix = '<td bgcolor="#5F7797" class="small" align="center" onmouseover="this.style.backgroundColor=\'#354463\';" onmouseout="this.style.backgroundColor=\'#5F7797\'">';
	$theme_link_suffix = '</td>';
	$theme_link_last_tag = "";


	$theme_link2_class = "link";
	$theme_link2_prefix = '<br> &nbsp; ';
	$theme_link2_suffix = ' &nbsp; <br>';
	$theme_link2_last_tag = "";
?>
